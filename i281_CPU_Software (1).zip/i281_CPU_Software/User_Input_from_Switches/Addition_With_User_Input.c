#include<stdio.h>

int x = 2; 
int y;
int result;

//Simple Addition with User input for the second variable (y)
void main() 
{
        scanf("%d", &y);
        result = x + y;
        //printf("%d", result);
}
