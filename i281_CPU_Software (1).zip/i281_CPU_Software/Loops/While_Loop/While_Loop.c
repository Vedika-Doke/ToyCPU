// While Loop 
//
// C version
//
// Add the numbers from 1 to 5 using a while loop.


int N=5;
int sum;
int i;

int main()
{
        i=1;
        sum=0;

        while( i <= N )
        {
                sum+=i;
                i++;
        }
}
