// Do Loop 
//
// C version
//
// Add the numbers from 1 to 5 using a do loop.


int N=5;
int sum;
int i;

int main()
{
        i=0;
        sum=0;

        do
        {
                i++;
                sum+=i;
        }while( i < N );
}
