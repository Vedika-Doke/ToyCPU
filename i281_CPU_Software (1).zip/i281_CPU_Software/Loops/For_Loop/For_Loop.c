// For Loop
//
// C version

// Add the numbers from 1 to 5 using a for loop.

int N=5;
int i, sum;

int main()
{
        sum=0;
        for(i=1; i<=N; i++) {
           sum+=i;
        }
        
        // printf("%d\n", sum);
}
