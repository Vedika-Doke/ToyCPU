
This file describes the software and the sample programs for the i281 CPU. 
In particular it shows how to use the i281 Assembler and the machine code
files that it generates. See also the README.txt in the hardware distribution,
which describes how to run the code on the CPU using the Altera board.


If you don't have java installed on your machine you'll need to install it first.
Compile the Assembler code by typing the following on the command line:

 javac i281assembler.java


Now you can use the i281 Assembler to compile your assembly programs to machine language. 
For example type the following on the command line:

 java i281assembler.java ./Sorting_Algorithms/Insertion_Sort/Insertion_Sort.asm

This will generate three different files in ./Sorting_Algorithms/Insertion_Sort/ 

    User_Code_Low.v
    User_Code_High.v
    User_Data.v

Copy these three files into the i281_CPU folder, overwriting the previous versions 
of these files. Then recompile the hardware design and load it into the Altera board.
From that point on you can follow the instructions in the hardware README.txt file
to execute the program on the CPU.


Here is how to compile another example:

 java i281assembler.java ./Loops/For_Loop/For_Loop.asm


The file Assembly_Mapping_v3.7.txt describes the mapping of the Assembly OPCODEs
to the machine language for this CPU. 


