// If-Else Statement
//
// C version


int main()
{
	int x=3;
	int y=5;
	int z;
	
	if (x<y)
	   z=x;
	else
	   z=y;
}
