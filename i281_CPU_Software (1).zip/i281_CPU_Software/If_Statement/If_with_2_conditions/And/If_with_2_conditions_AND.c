// If Statement with Two Conditions (AND)
//
// C version


int main()
{
        int x=5;
        int min=1;
        int max=8;
        int inRange=0;

        if ( (x>=min) && (x<=max) )
          inRange=1;
}
