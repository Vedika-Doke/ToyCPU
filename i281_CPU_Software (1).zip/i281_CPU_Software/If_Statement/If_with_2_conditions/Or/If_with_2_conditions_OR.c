// If Statement with Two Conditions (OR)
//
// C version


int main()
{
        int x=9;
        int min=1;
        int max=8;
        int inRange=1;

        if ( (x<min) || (x>max) )
          inRange=0;
}
