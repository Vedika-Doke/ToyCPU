// If Not Equal
//
// C version


int main()
{
        int x=3;
        int y=5;
        int z=0;
        
        if (x!=y)
           z=x;
}
