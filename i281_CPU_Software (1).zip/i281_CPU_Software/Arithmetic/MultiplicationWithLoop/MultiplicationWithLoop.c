// Multiplication With Loop
//
// C version


int main()
{
        int x=3;
        int z;
        
        z = x*5;

        // printf("%d\n", z);
}
