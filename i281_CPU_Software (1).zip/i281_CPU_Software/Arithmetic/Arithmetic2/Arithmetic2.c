// Arithmetic
//
// C version


int main()
{
        int x=2;
        int y=3;
        int z;
        
        z = x+y;

        // printf("%d\n", z);
}
