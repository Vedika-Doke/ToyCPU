// Multiplication
//
// C version


int main()
{
        int x=2;
        int z;
        
        z = x*5;

        // printf("%d\n", z);
}
