// Array
//
// C version

int array[]={1, 2, 3, 4};

int main()
{
        array[0]  = 0;

        array[1] += 5;

        array[2] -= 1;

        array[3] += array[2];
        
        // print the array
        // int i;
        // for(i=0; i<4; i++) {
        //   printf("%d, ", array[i]);
        // }
}
