// Array plus 5
//
// C version

int array[]={1, 2, 3, 4};
int N = 4;

int main()
{
        int i;

        // add 5 to all array elements        
        for( i=0; i< N; i++)
        {
                array[i] += 5;
        }
        
        // print the array1
        // for(i=0; i< N; i++) {
        //   printf("%d, ", array[i]);
        // }
}
